# JanuSync Platform Chart
This chart Support EKS or NKS

### Helm App Version Support:
helm version: app-version

0.0.5: 1.1.0

0.0.6: 1.2.0

0.0.7: 1.3.0

### Prerequisites:
1. Istio (선행절차: gateway-NLB 설정)
2. Management portal front(별도 설정 필요)

### External Option:
1. EKS
- S3 CSI Driver(require)

## General parameters

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| additionalLabels | object | `{}` | Common labels for the all resources |
| affinity.nodeAffinity.matchExpressions | list | `[]` | Default match expressions for node affinity Can be overridden in detailed settings |
| affinity.nodeAffinity.type | string | `"hard"` | Default node affinity rules. Either: `none`, `soft` or `hard` |
| deploymentAnnotations | object | `{}` | Annotations for the all deployed Deployments |
| env | list | `[{"name":"TZ","value":"Asia/Seoul"}]` | Environment variables to pass to all deployed Deployments |
| event-action-consumer.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| event-action-consumer.deploymentAnnotations | object | `{}` | Annotations to be added to the event-action-consumer Deployment |
| event-action-consumer.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to event-action-consumer |
| event-action-consumer.extraEnv | list | `[]` | Environment variables to pass to event-action-consumer |
| event-action-consumer.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the event-action-consumer |
| event-action-consumer.name | string | `"event-action-consumer"` | event-action-consumer name string |
| event-action-consumer.podAnnotations | object | `{}` | Annotations to be added to event-action-consumer pods |
| event-action-consumer.podLabels | object | `{}` | Labels for the deployed pods |
| event-action-consumer.replicas | int | `1` | The number of event-action-consumer pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| event-action-consumer.resources | object | `{"limits":{"cpu":"500m","memory":"512Mi"},"requests":{"cpu":"100m","memory":"256Mi"}}` | Resource limits and requests for the event-action-consumer pods |
| event-action-consumer.tag | string | `""` | event-action-consumer image tag |
| event-action-consumer.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| event-action-consumer.volumeMounts | list | `[]` | Additional volumeMounts to the event-action-consumer main container |
| event-action-consumer.volumes | list | `[]` | Additional volumes to the event-action-consumer pod |
| image.imagePullPolicy | string | `"IfNotPresent"` | If defined, a imagePullPolicy applied to all deployments |
| image.repository | string | `"551185747239.dkr.ecr.ap-northeast-2.amazonaws.com/dtx"` | If defined, a repository applied to all deployments |
| image.tag | string | `""` | Overrides the global image tag whose default is the chart appVersion |
| imagePullSecrets | list | `[]` | Secrets with credentials to pull images from a private registry |
| kubernetesType | string | `"eks"` | Kubernetes Management Service Name support: eks or etc |
| nameOverride | string | `"janusync"` | Provide a name in place of `janusync` |
| podAnnotations | object | `{}` | Annotations for the all deployed pods |
| podLabels | object | `{}` | Labels for the all deployed pods |
| revisionHistoryLimit | int | `3` | Number of old deployment ReplicaSets to retain. The rest will be garbage collected. |
| statefulsetAnnotations | object | `{}` | Annotations for the all deployed Statefulsets |
| tolerations | list | `[]` | Default tolerations for all components |

## JanuSync Platform Configs

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| configs.apiHostName | list | `["api.connectdtx.net","api.janusync.com"]` | External API Host |
| configs.consentHostName | string | `"consent.janusync.com"` |  |
| configs.development | string | `"false"` |  |
| configs.istioGatewayName | string | `"common-ingress"` | Istio Gateway Name |
| configs.istioGatewayPort | int | `443` | Istio Gateway Port |

## Backup Configs
repository 백업 설정

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| backup.cronSchedule | string | `"0 20 * * *"` | Default KST 기준 오전 5시 |
| backup.enable | string | `"false"` |  |
| backup.maxBackupCount | string | `"1"` | 원격(소산)백업 시 백업 파일을 몇 개나 유지할지 |
| backup.maxSnapshot | string | `"1"` | 스냅샷을 몇 개나 유지할지 |
| backup.remoteBackup | string | `"false"` |  |
| backup.serviceAccount | string | `"repository-backup"` |  |

## EKS Configs

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| eks.bucketPreFix | string | `"janusync-report-data"` | result report S3 bucket name prefix |
| eks.bucketRegion | string | `"ap-northeast-2"` | result report S3 bucket region |

## ETC k8s Cluster Configs

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| etcCluster.dtxReportStorageClassName | string | `""` | DTx Report pvc storage class |

## Consumer

### Audit Consumer

| Key | Type | Default | Description |
|-----|------|---------|-------------|

### SMS Consumer

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| consumer-sms.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| consumer-sms.deploymentAnnotations | object | `{}` | Annotations to be added to the sms consumer Deployment |
| consumer-sms.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to sms consumer |
| consumer-sms.extraEnv | list | `[]` | Environment variables to pass to sms consumer |
| consumer-sms.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the sms consumer |
| consumer-sms.name | string | `"consumer-sms"` | sms consumer name string |
| consumer-sms.podAnnotations | object | `{}` | Annotations to be added to sms consumer pods |
| consumer-sms.podLabels | object | `{}` | Labels for the deployed pods |
| consumer-sms.replicas | int | `1` | The number of sms consumer pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| consumer-sms.resources | object | `{"limits":{"cpu":"300m","memory":"512Mi"},"requests":{"cpu":"300m","memory":"512Mi"}}` | Resource limits and requests for the sms consumer pods |
| consumer-sms.tag | string | `""` | sms consumer image tag |
| consumer-sms.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| consumer-sms.volumeMounts | list | `[]` | Additional volumeMounts to the sms consumer main container |
| consumer-sms.volumes | list | `[]` | Additional volumes to the sms consumer pod |

### Mail Consumer

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| consumer-mail.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| consumer-mail.deploymentAnnotations | object | `{}` | Annotations to be added to the mail consumer Deployment |
| consumer-mail.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to mail consumer |
| consumer-mail.extraEnv | list | `[]` | Environment variables to pass to mail consumer |
| consumer-mail.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the mail consumer |
| consumer-mail.name | string | `"consumer-mail"` | mail consumer name string |
| consumer-mail.podAnnotations | object | `{}` | Annotations to be added to mail consumer pods |
| consumer-mail.podLabels | object | `{}` | Labels for the deployed pods |
| consumer-mail.replicas | int | `1` | The number of mail consumer pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| consumer-mail.resources | object | `{}` | Resource limits and requests for the mail consumer pods |
| consumer-mail.tag | string | `""` | mail consumer image tag |
| consumer-mail.volumeMounts | list | `[]` | Additional volumeMounts to the mail consumer main container |
| consumer-mail.volumes | list | `[]` | Additional volumes to the mail consumer pod |

### External Module Log Consumer

| Key | Type | Default | Description |
|-----|------|---------|-------------|

### Patient Data Flow Consumer

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| consumer-patient-data-flow.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| consumer-patient-data-flow.deploymentAnnotations | object | `{}` | Annotations to be added to the patient-data-flow-consumer Deployment |
| consumer-patient-data-flow.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to patient-data-flow-consumer |
| consumer-patient-data-flow.extraEnv | list | `[]` | Environment variables to pass to patient-data-flow-consumer |
| consumer-patient-data-flow.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the patient-data-flow-consumer |
| consumer-patient-data-flow.name | string | `"patient-data-flow"` | patient-data-flow-consumer name string |
| consumer-patient-data-flow.podAnnotations | object | `{}` | Annotations to be added to patient-data-flow-consumer pods |
| consumer-patient-data-flow.podLabels | object | `{}` | Labels for the deployed pods |
| consumer-patient-data-flow.replicas | int | `1` | The number of patient-data-flow-consumer pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| consumer-patient-data-flow.resources | object | `{}` | Resource limits and requests for the patient-data-flow-consumer pods |
| consumer-patient-data-flow.tag | string | `""` | patient-data-flow-consumer image tag |
| consumer-patient-data-flow.volumeMounts | list | `[]` | Additional volumeMounts to the patient-data-flow-consumer main container |
| consumer-patient-data-flow.volumes | list | `[]` | Additional volumes to the patient-data-flow-consumer pod |

## legacy

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| legacy.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| legacy.autoScaling | object | `{"enable":"true","maxReplicas":3,"metrics":[{"resource":{"name":"cpu","target":{"averageUtilization":80,"type":"Utilization"}},"type":"Resource"}]}` | https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/ 참조 |
| legacy.deploymentAnnotations | object | `{}` | Annotations to be added to the legacy Deployment |
| legacy.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to legacy |
| legacy.extraEnv | list | `[]` | Environment variables to pass to legacy |
| legacy.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the legacy |
| legacy.name | string | `"legacy"` | legacy name string |
| legacy.podAnnotations | object | `{}` | Annotations to be added to legacy pods |
| legacy.podLabels | object | `{}` | Labels for the deployed pods |
| legacy.replicas | int | `1` | The number of legacy pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| legacy.resources | object | `{"limits":{"cpu":"1000m","memory":"512Mi"},"requests":{"cpu":"100m","memory":"512Mi"}}` | Resource limits and requests for the legacy pods |
| legacy.tag | string | `""` | legacy image tag |
| legacy.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| legacy.volumeMounts | list | `[]` | Additional volumeMounts to the legacy main container |
| legacy.volumes | list | `[]` | Additional volumes to the legacy pod |

## OAuth

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| oauth.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| oauth.autoScaling | object | `{"enable":"true","maxReplicas":4,"metrics":[{"resource":{"name":"cpu","target":{"averageUtilization":80,"type":"Utilization"}},"type":"Resource"}]}` | https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/ 참조 |
| oauth.deploymentAnnotations | object | `{}` | Annotations to be added to the oauth Deployment |
| oauth.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to oauth |
| oauth.extraEnv | list | `[]` | Environment variables to pass to oauth |
| oauth.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the oauth |
| oauth.name | string | `"oauth2"` | oauth name string |
| oauth.podAnnotations | object | `{}` | Annotations to be added to oauth pods |
| oauth.podLabels | object | `{}` | Labels for the deployed pods |
| oauth.replicas | int | `1` | The number of oauth pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| oauth.resources | object | `{"limits":{"cpu":"1000m","memory":"512Mi"},"requests":{"cpu":"500m","memory":"512Mi"}}` | Resource limits and requests for the oauth pods |
| oauth.tag | string | `""` | oauth image tag |
| oauth.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| oauth.volumeMounts | list | `[]` | Additional volumeMounts to the oauth main container |
| oauth.volumes | list | `[]` | Additional volumes to the oauth pod |

## PHI code Auth

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| phi-auth.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| phi-auth.autoScaling | object | `{"enable":"true","maxReplicas":4,"metrics":[{"resource":{"name":"cpu","target":{"averageUtilization":80,"type":"Utilization"}},"type":"Resource"}]}` | https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/ 참조 |
| phi-auth.deploymentAnnotations | object | `{}` | Annotations to be added to the PHI code Auth Deployment |
| phi-auth.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to PHI code |
| phi-auth.extraEnv | list | `[]` | Environment variables to pass to PHI code Auth |
| phi-auth.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the PHI code Auth |
| phi-auth.name | string | `"phi-auth"` | PHI code Auth name string |
| phi-auth.podAnnotations | object | `{}` | Annotations to be added to PHI code Auth pods |
| phi-auth.podLabels | object | `{}` | Labels for the deployed pods |
| phi-auth.replicas | int | `1` | The number of PHI code Auth pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| phi-auth.resources | object | `{"limits":{"cpu":"1000m","memory":"512Mi"},"requests":{"cpu":"500m","memory":"512Mi"}}` | Resource limits and requests for the PHI code Auth pods |
| phi-auth.tag | string | `""` | PHI code Auth image tag |
| phi-auth.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| phi-auth.volumeMounts | list | `[]` | Additional volumeMounts to the PHI code Auth main container |
| phi-auth.volumes | list | `[]` | Additional volumes to the PHI code Auth pod |

## Portal

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| portal.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| portal.autoScaling | object | `{"enable":"false"}` | https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/ 참조 |
| portal.containerPort | int | `8089` | portal container port |
| portal.deploymentAnnotations | object | `{}` | Annotations to be added to the portal Deployment |
| portal.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to portal |
| portal.extraEnv | list | `[]` | Environment variables to pass to portal |
| portal.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the portal |
| portal.name | string | `"portal"` | portal name string |
| portal.podAnnotations | object | `{}` | Annotations to be added to portal pods |
| portal.podLabels | object | `{}` | Labels for the deployed pods |
| portal.replicas | int | `1` | The number of portal pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| portal.resources | object | `{"limits":{"memory":"1Gi"},"requests":{"memory":"1Gi"}}` | Resource limits and requests for the portal pods |
| portal.tag | string | `""` | portal image tag |
| portal.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| portal.volumeMounts | list | `[{"mountPath":"/volume","name":"report-volume"}]` | Additional volumeMounts to the portal main container |
| portal.volumes | list | `[{"name":"report-volume","persistentVolumeClaim":{"claimName":"dtx-report-pvc"}}]` | Additional volumes to the portal pod |

## Scheduler

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| scheduler.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| scheduler.deploymentAnnotations | object | `{}` | Annotations to be added to the scheduler Deployment |
| scheduler.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to scheduler |
| scheduler.extraEnv | list | `[]` | Environment variables to pass to scheduler |
| scheduler.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the scheduler |
| scheduler.name | string | `"scheduler"` | scheduler name string |
| scheduler.podAnnotations | object | `{}` | Annotations to be added to scheduler pods |
| scheduler.podLabels | object | `{}` | Labels for the deployed pods |
| scheduler.replicas | int | `1` | The number of scheduler pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| scheduler.resources | object | `{"limits":{"memory":"512Mi"},"requests":{"memory":"256Mi"}}` | Resource limits and requests for the scheduler pods |
| scheduler.tag | string | `""` | scheduler image tag |
| scheduler.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| scheduler.volumeMounts | list | `[]` | Additional volumeMounts to the scheduler main container |
| scheduler.volumes | list | `[]` | Additional volumes to the scheduler pod |

## External Bridge

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| external-bridge.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| external-bridge.autoScaling | object | `{"enable":"true","maxReplicas":3,"metrics":[{"resource":{"name":"cpu","target":{"averageUtilization":80,"type":"Utilization"}},"type":"Resource"}]}` | https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/ 참조 |
| external-bridge.deploymentAnnotations | object | `{}` | Annotations to be added to the external-bridge Deployment |
| external-bridge.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to external-bridge |
| external-bridge.extraEnv | list | `[]` | Environment variables to pass to external-bridge |
| external-bridge.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the external-bridge |
| external-bridge.name | string | `"external-bridge"` | external-bridge name string |
| external-bridge.podAnnotations | object | `{}` | Annotations to be added to external-bridge pods |
| external-bridge.podLabels | object | `{}` | Labels for the deployed pods |
| external-bridge.replicas | int | `1` | The number of external-bridge pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| external-bridge.resources | object | `{"limits":{"cpu":"1000m","memory":"512Mi"},"requests":{"cpu":"100m","memory":"256Mi"}}` | Resource limits and requests for the external-bridge pods |
| external-bridge.tag | string | `""` | external-bridge image tag |
| external-bridge.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| external-bridge.volumeMounts | list | `[]` | Additional volumeMounts to the external-bridge main container |
| external-bridge.volumes | list | `[]` | Additional volumes to the external-bridge pod |

## disposal

| Key | Type | Default | Description |
|-----|------|---------|-------------|

## FHIR Module

### HAPI Fhir

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| hapi-fhir.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| hapi-fhir.autoScaling | object | `{"enable":"false"}` | https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/ 참조 |
| hapi-fhir.containerPort | int | `8082` | hapi-fhir container port |
| hapi-fhir.deploymentAnnotations | object | `{}` | Annotations to be added to the hapi-fhir Deployment |
| hapi-fhir.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to hapi-fhir |
| hapi-fhir.extraEnv | list | `[]` | Environment variables to pass to hapi-fhir |
| hapi-fhir.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the hapi-fhir |
| hapi-fhir.name | string | `"hapi-fhir"` | hapi-fhir name string |
| hapi-fhir.podAnnotations | object | `{}` | Annotations to be added to hapi-fhir pods |
| hapi-fhir.podLabels | object | `{}` | Labels for the deployed pods |
| hapi-fhir.replicas | int | `1` | The number of hapi-fhir pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| hapi-fhir.resources | object | `{"limits":{"memory":"2Gi"},"requests":{"memory":"2Gi"}}` | Resource limits and requests for the hapi-fhir pods |
| hapi-fhir.tag | string | `"6.4.0"` | hapi-fhir image tag |
| hapi-fhir.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| hapi-fhir.volumeMounts | list | `[]` | Additional volumeMounts to the hapi-fhir main container |
| hapi-fhir.volumes | list | `[]` | Additional volumes to the hapi-fhir pod |

### FHIR batch

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| fhir-batch.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| fhir-batch.deploymentAnnotations | object | `{}` | Annotations to be added to the fhir batch Deployment |
| fhir-batch.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to fhir batch |
| fhir-batch.extraEnv | list | `[]` | Environment variables to pass to fhir batch |
| fhir-batch.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the fhir batch |
| fhir-batch.name | string | `"fhir-batch"` | fhir batch name string |
| fhir-batch.podAnnotations | object | `{}` | Annotations to be added to fhir batch pods |
| fhir-batch.podLabels | object | `{}` | Labels for the deployed pods |
| fhir-batch.replicas | int | `1` | The number of fhir batch pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| fhir-batch.resources | object | `{"limits":{"memory":"2Gi"},"requests":{"memory":"1Gi"}}` | Resource limits and requests for the fhir-batch pods |
| fhir-batch.tag | string | `""` | fhir batch image tag |
| fhir-batch.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| fhir-batch.volumeMounts | list | `[{"mountPath":"/volume","name":"report-volume"}]` | Additional volumeMounts to the fhir batch main container |
| fhir-batch.volumes | list | `[{"name":"report-volume","persistentVolumeClaim":{"claimName":"dtx-report-pvc"}}]` | Additional volumes to the fhir batch pod |

### FHIR gateway

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| fhir-gateway.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| fhir-gateway.autoScaling | object | `{"enable":"false"}` | https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/ 참조 |
| fhir-gateway.deploymentAnnotations | object | `{}` | Annotations to be added to the fhir gateway Deployment |
| fhir-gateway.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to fhir gateway |
| fhir-gateway.extraEnv | list | `[]` | Environment variables to pass to fhir gateway |
| fhir-gateway.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the fhir gateway |
| fhir-gateway.name | string | `"fhir-gateway"` | fhir gateway name string |
| fhir-gateway.podAnnotations | object | `{}` | Annotations to be added to fhir gateway pods |
| fhir-gateway.podLabels | object | `{}` | Labels for the deployed pods |
| fhir-gateway.replicas | int | `1` | The number of fhir gateway pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| fhir-gateway.resources | object | `{"limits":{"memory":"3Gi"},"requests":{"memory":"1Gi"}}` | Resource limits and requests for the fhir-gateway pods |
| fhir-gateway.tag | string | `""` | fhir gateway image tag |
| fhir-gateway.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| fhir-gateway.volumeMounts | list | `[{"mountPath":"/volume","name":"report-volume"}]` | Additional volumeMounts to the fhir gateway main container |
| fhir-gateway.volumes | list | `[{"name":"report-volume","persistentVolumeClaim":{"claimName":"dtx-report-pvc"}}]` | Additional volumes to the fhir gateway pod |

### FHIR batch fail notify

| Key | Type | Default | Description |
|-----|------|---------|-------------|

## Notify Module

### Notify Manager

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| notify-manager.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| notify-manager.deploymentAnnotations | object | `{}` | Annotations to be added to the notify-manager Deployment |
| notify-manager.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to notify-manager |
| notify-manager.extraEnv | list | `[]` | Environment variables to pass to notify-manager |
| notify-manager.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the notify-manager |
| notify-manager.name | string | `"notify-manager"` | notify-manager name string |
| notify-manager.podAnnotations | object | `{}` | Annotations to be added to notify-manager pods |
| notify-manager.podLabels | object | `{}` | Labels for the deployed pods |
| notify-manager.replicas | int | `1` | The number of notify-manager pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| notify-manager.resources | object | `{"limits":{"memory":"512Mi"},"requests":{"memory":"512Mi"}}` | Resource limits and requests for the notify-manager pods |
| notify-manager.tag | string | `""` | notify-manager image tag |
| notify-manager.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| notify-manager.volumeMounts | list | `[]` | Additional volumeMounts to the notify-manager main container |
| notify-manager.volumes | list | `[]` | Additional volumes to the notify-manager pod |

### Notify Transfer

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| notify-transfer.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| notify-transfer.deploymentAnnotations | object | `{}` | Annotations to be added to the notify-transfer Deployment |
| notify-transfer.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to notify-transfer |
| notify-transfer.extraEnv | list | `[]` | Environment variables to pass to notify-transfer |
| notify-transfer.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the notify-transfer |
| notify-transfer.name | string | `"notify-transfer"` | notify-transfer name string |
| notify-transfer.podAnnotations | object | `{}` | Annotations to be added to notify-transfer pods |
| notify-transfer.podLabels | object | `{}` | Labels for the deployed pods |
| notify-transfer.replicas | int | `1` | The number of notify-transfer pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| notify-transfer.resources | object | `{"limits":{"memory":"512Mi"},"requests":{"memory":"512Mi"}}` | Resource limits and requests for the notify-transfer pods |
| notify-transfer.tag | string | `""` | notify-transfer image tag |
| notify-transfer.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| notify-transfer.volumeMounts | list | `[]` | Additional volumeMounts to the notify-transfer main container |
| notify-transfer.volumes | list | `[]` | Additional volumes to the notify-transfer pod |

## Consent Manager

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| consent-manager.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| consent-manager.autoScaling | object | `{"enable":"true","maxReplicas":3,"metrics":[{"resource":{"name":"cpu","target":{"averageUtilization":80,"type":"Utilization"}},"type":"Resource"}]}` | https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/ 참조 |
| consent-manager.deploymentAnnotations | object | `{}` | Annotations to be added to the consent-manager Deployment |
| consent-manager.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to consent-manager |
| consent-manager.extraEnv | list | `[]` | Environment variables to pass to consent-manage |
| consent-manager.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the consent-manage |
| consent-manager.name | string | `"consent-manager"` | consent-manager name string |
| consent-manager.podAnnotations | object | `{}` | Annotations to be added to consent-manager pods |
| consent-manager.podLabels | object | `{}` | Labels for the deployed pods |
| consent-manager.replicas | int | `1` | The number of fhir gateway pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| consent-manager.resources | object | `{"limits":{"cpu":"1500m","memory":"512Mi"},"requests":{"cpu":"500m","memory":"512Mi"}}` | Resource limits and requests for the consent-manager pods |
| consent-manager.tag | string | `""` | consent-manage image tag |
| consent-manager.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| consent-manager.volumeMounts | list | `[]` | Additional volumeMounts to the consent-manager main container |
| consent-manager.volumes | list | `[]` | Additional volumes to the consent-manager pod |

## External Module Log Listener

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| external-log-listener.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| external-log-listener.autoScaling | object | `{"enable":"true","maxReplicas":2,"metrics":[{"resource":{"name":"cpu","target":{"averageUtilization":80,"type":"Utilization"}},"type":"Resource"}]}` | https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/ 참조 |
| external-log-listener.deploymentAnnotations | object | `{}` | Annotations to be added to the log-listener Deployment |
| external-log-listener.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to log-listener |
| external-log-listener.extraEnv | list | `[]` | Environment variables to pass to log-listener |
| external-log-listener.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the log-listener |
| external-log-listener.name | string | `"external-log-listener"` |  |
| external-log-listener.podAnnotations | object | `{}` | Annotations to be added to log-listener pods |
| external-log-listener.podLabels | object | `{}` | Labels for the deployed pods |
| external-log-listener.replicas | int | `1` | The number of log-listener pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| external-log-listener.resources | object | `{"limits":{"cpu":"1000m","memory":"512Mi"},"requests":{"cpu":"500m","memory":"512Mi"}}` | Resource limits and requests for the log-listener pods |
| external-log-listener.tag | string | `""` | log-listener image tag |
| external-log-listener.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| external-log-listener.volumeMounts | list | `[]` | Additional volumeMounts to the log-listener main container |
| external-log-listener.volumes | list | `[]` | Additional volumes to the log-listener pod |

## Data Processor

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| data-processor.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| data-processor.containerPort | int | `8180` |  |
| data-processor.deploymentAnnotations | object | `{}` |  |
| data-processor.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to data-processor |
| data-processor.extraEnv | list | `[]` |  |
| data-processor.imagePullPolicy | string | `""` |  |
| data-processor.name | string | `"data-processor"` |  |
| data-processor.podAnnotations | object | `{}` |  |
| data-processor.podLabels | object | `{}` |  |
| data-processor.replicas | int | `1` |  |
| data-processor.resources.limits.cpu | string | `"1000m"` |  |
| data-processor.resources.limits.memory | string | `"512Mi"` |  |
| data-processor.resources.requests.cpu | string | `"200m"` |  |
| data-processor.resources.requests.memory | string | `"256Mi"` |  |
| data-processor.tag | string | `""` |  |
| data-processor.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| data-processor.volumeMounts | list | `[]` |  |
| data-processor.volumes | list | `[]` |  |
