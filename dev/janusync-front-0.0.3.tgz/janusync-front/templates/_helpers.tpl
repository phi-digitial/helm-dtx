{{/*
Create name and version as used by the chart label.
Truncated at 52 chars because Deployment label '' is limited
to 63 chars and it includes 10 chars of hash and a separating '-'.
*/}}

{{- define "janusync.gateway.name" -}}
{{- printf "%s-gateway" (include "chart.fullname" .) | trunc 52 | trimSuffix "-" -}}
{{- end -}}
