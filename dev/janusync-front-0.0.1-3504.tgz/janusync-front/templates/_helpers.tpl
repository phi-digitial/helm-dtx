{{/*
Create name and version as used by the chart label.
Truncated at 52 chars because Deployment label '' is limited
to 63 chars and it includes 10 chars of hash and a separating '-'.
*/}}

{{- define "janusync.portal-front.fullname" -}}
{{- printf "%s-management-front" (include "chart.fullname" .) | trunc 52 | trimSuffix "-" -}}
{{- end -}}

{{- define "janusync.opr-portal-front.fullname" -}}
{{- printf "%s-operation-front" (include "chart.fullname" .) | trunc 52 | trimSuffix "-" -}}
{{- end -}}

{{- define "janusync.consent-front.fullname" -}}
{{- printf "%s-consent-front" (include "chart.fullname" .) | trunc 52 | trimSuffix "-" -}}
{{- end -}}

{{- define "janusync.gateway.name" -}}
{{- printf "%s-gateway-front" (include "chart.fullname" .) | trunc 52 | trimSuffix "-" -}}
{{- end -}}
