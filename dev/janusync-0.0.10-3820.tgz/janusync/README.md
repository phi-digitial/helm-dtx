# JanuSync Platform Chart

### Helm App Version Support:
helm version: app-version

0.0.5: 1.1.0

0.0.6: 1.2.0

0.0.7: 1.3.0

0.0.8: 1.4.0

0.0.9: 1.4.3

0.0.10: 1.5.0

### Prerequisites:
1. Istio (선행절차: gateway-NLB 설정)
2. Management portal front(별도 설정 필요)

## General parameters

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| additionalLabels | object | `{}` | Common labels for the all resources |
| affinity.nodeAffinity.matchExpressions | list | `[]` | Default match expressions for node affinity Can be overridden in detailed settings |
| affinity.nodeAffinity.type | string | `"hard"` | Default node affinity rules. Either: `none`, `soft` or `hard` |
| deploymentAnnotations | object | `{}` | Annotations for the all deployed Deployments |
| env | list | `[{"name":"TZ","value":"Asia/Seoul"}]` | Environment variables to pass to all deployed |
| envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to all deployed |
| image.imagePullPolicy | string | `"IfNotPresent"` | If defined, a imagePullPolicy applied to all deployments |
| image.repository | string | `"551185747239.dkr.ecr.ap-northeast-2.amazonaws.com/dtx"` | If defined, a repository applied to all deployments |
| image.tag | string | `""` | Overrides the global image tag whose default is the chart appVersion |
| imagePullSecrets | list | `[]` | Secrets with credentials to pull images from a private registry |
| nameOverride | string | `"janusync"` | Provide a name in place of `janusync` |
| podAnnotations | object | `{}` | Annotations for the all deployed pods |
| podLabels | object | `{}` | Labels for the all deployed pods |
| revisionHistoryLimit | int | `3` | Number of old deployment ReplicaSets to retain. The rest will be garbage collected. |
| statefulsetAnnotations | object | `{}` | Annotations for the all deployed Statefulsets |
| tolerations | list | `[]` | Default tolerations for all components |

## JanuSync Platform Configs

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| configs.apiHostName | list | `["api.connectdtx.net","api.janusync.com"]` | External API Host |
| configs.development | string | `"false"` |  |
| configs.istioGatewayName | string | `"common-ingress"` | Istio Gateway Name |
| configs.istioGatewayPort | int | `443` | Istio Gateway Port |
| configs.kafka | object | `{"common":{"bootstrap.servers":""},"consumer":{"auto.offset.reset":"latest","enable.auto.commit":"false","group.id":"janusync","key.deserializer":"org.apache.kafka.common.serialization.StringDeserializer","value.deserializer":"org.apache.kafka.common.serialization.StringDeserializer"},"producer":{"acks":"all","enable.idempotence":"true","key.serializer":"org.apache.kafka.common.serialization.StringSerializer","max.in.flight.requests.per.connection":"1","retries":"10","retry.backoff.ms":"1000","value.serializer":"org.apache.kafka.common.serialization.StringSerializer"}}` | kafka 연결 정보 |
| configs.kafka.common."bootstrap.servers" | string | `""` | Kafka 브로커 연결 주소. 기본값은 현재 네임스페이스 기반으로 자동 설정됨 (`kafka-bootstrap.<namespace>.svc.cluster.local:9092`) |
| configs.kafka.consumer."auto.offset.reset" | string | `"latest"` | 초기 오프셋 정책. `latest`는 컨슈머 기동 후 새로 발행되는 메시지만 소비 |
| configs.kafka.consumer."enable.auto.commit" | string | `"false"` | 오프셋 자동 커밋 비활성화. 수동 커밋으로 메시지 처리 완료 후 커밋 보장 |
| configs.kafka.consumer."group.id" | string | `"janusync"` | 컨슈머 그룹 ID. 동일 그룹 내에서 파티션이 분산 할당됨 |
| configs.kafka.consumer."key.deserializer" | string | `"org.apache.kafka.common.serialization.StringDeserializer"` | 컨슈머 메시지 키 역직렬화 클래스 |
| configs.kafka.consumer."value.deserializer" | string | `"org.apache.kafka.common.serialization.StringDeserializer"` | 컨슈머 메시지 값 역직렬화 클래스 |
| configs.kafka.producer."enable.idempotence" | string | `"true"` | 멱등성 프로듀서 활성화. 중복 메시지 방지 (exactly-once 시맨틱의 기초) |
| configs.kafka.producer."key.serializer" | string | `"org.apache.kafka.common.serialization.StringSerializer"` | 프로듀서 메시지 키 직렬화 클래스 |
| configs.kafka.producer."max.in.flight.requests.per.connection" | string | `"1"` | 커넥션당 최대 in-flight 요청 수. idempotence 활성화 시 5 이하 필수, 순서 보장 목적 시 1로 설정 |
| configs.kafka.producer."retry.backoff.ms" | string | `"1000"` | 재시도 간격 (밀리초) |
| configs.kafka.producer."value.serializer" | string | `"org.apache.kafka.common.serialization.StringSerializer"` | 프로듀서 메시지 값 직렬화 클래스 |
| configs.kafka.producer.acks | string | `"all"` | 프로듀서 ACK 정책. `all`은 ISR 전체 복제 확인 후 응답 (데이터 유실 방지 최강) |
| configs.kafka.producer.retries | string | `"10"` | 전송 실패 시 최대 재시도 횟수 |
| configs.services.consentUrl | string | `""` | Consent Manager 서비스 URL. 미입력시 http://janusync-consent-manager.<namespace>.svc.cluster.local |
| configs.services.consentWebUrl | string | `"consent.janusync.com"` | Consent 웹 외부 도메인. 필수 입력 |
| configs.services.fhirGatewayUrl | string | `""` | FHIR Gateway 서비스 URL. 미입력시 http://janusync-fhir-gateway.<namespace>.svc.cluster.local |
| configs.services.fhirUrl | string | `""` | FHIR 서버 URL. 미입력시 http://janusync-hapi-fhir.<namespace>.svc.cluster.local |
| configs.services.govDomain | string | `"api.gov.janusync.com"` | 운영존 도메인. 필수 |
| configs.services.notifyManagerUrl | string | `""` | Notify Manager 서비스 URL. 미입력시 http://janusync-notify-manager.<namespace>.svc.cluster.local |
| configs.services.oauthUrl | string | `""` | OAuth 서비스 URL. 미입력시 http://janusync-oauth.<namespace>.svc.cluster.local |
| configs.services.phiAuthUrl | string | `""` | PHI Auth 서비스 URL. 미입력시 http://janusync-phi-auth.<namespace>.svc.cluster.local |
| configs.services.prodDomain | string | `"api.janusync.com"` | 민간존 도메인. 필수 |
| configs.services.providerManagerUrl | string | `""` | Provider Manager 서비스 URL. 미입력시 http://janusync-provider-manager.<namespace>.svc.cluster.local |
| configs.services.zone | string | `"prod"` | 배포 존 타입. prod | gov |

## Mongo Migrator

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| mongo-migrator.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| mongo-migrator.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to log-listener |
| mongo-migrator.extraEnv | list | `[]` | Environment variables to pass to log-listener |
| mongo-migrator.imageName | string | `"tools/mongo-migrator"` | mongoMigration name string |
| mongo-migrator.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the mongoMigration |
| mongo-migrator.podAnnotations | object | `{}` | Annotations to be added to mongoMigration pods |
| mongo-migrator.podLabels | object | `{}` | Labels for the deployed pods |
| mongo-migrator.resources | object | `{}` | Resource limits and requests for the mongoMigration pods |
| mongo-migrator.serviceAccount.annotations | object | `{}` | Annotations applied to created service account |
| mongo-migrator.serviceAccount.automountServiceAccountToken | bool | `false` | Automount API credentials for the Service Account |
| mongo-migrator.serviceAccount.create | string | `"false"` | Create a ServiceAccount only when set to "true" (string, not boolean) |
| mongo-migrator.serviceAccount.labels | object | `{}` | Labels applied to created service account |
| mongo-migrator.serviceAccount.name | string | `""` | Service account name |
| mongo-migrator.tag | string | `""` | mongoMigration image tag |
| mongo-migrator.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| mongo-migrator.volumeMounts | list | `[]` | Additional volumeMounts to the mongoMigration main container |
| mongo-migrator.volumes | list | `[]` | Additional volumes to the mongoMigration pod |

## Consumer

### Event Action Consumer

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| event-action-consumer.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| event-action-consumer.deploymentAnnotations | object | `{}` | Annotations to be added to the event-action-consumer Deployment |
| event-action-consumer.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to event-action-consumer |
| event-action-consumer.extraEnv | list | `[]` | Environment variables to pass to event-action-consumer |
| event-action-consumer.imageName | string | `"datamanager/event-action-consumer"` | event-action-consumer imageName string |
| event-action-consumer.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the event-action-consumer |
| event-action-consumer.podAnnotations | object | `{}` | Annotations to be added to event-action-consumer pods |
| event-action-consumer.podLabels | object | `{}` | Labels for the deployed pods |
| event-action-consumer.replicas | int | `1` | The number of event-action-consumer pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| event-action-consumer.resources | object | `{"limits":{"cpu":"500m","memory":"512Mi"},"requests":{"cpu":"100m","memory":"256Mi"}}` | Resource limits and requests for the event-action-consumer pods |
| event-action-consumer.serviceAccount.annotations | object | `{}` | Annotations applied to created service account |
| event-action-consumer.serviceAccount.automountServiceAccountToken | bool | `false` | Automount API credentials for the Service Account |
| event-action-consumer.serviceAccount.create | string | `"false"` | Create a ServiceAccount only when set to "true" (string, not boolean) |
| event-action-consumer.serviceAccount.labels | object | `{}` | Labels applied to created service account |
| event-action-consumer.serviceAccount.name | string | `""` | Service account name |
| event-action-consumer.tag | string | `""` | event-action-consumer image tag |
| event-action-consumer.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| event-action-consumer.volumeMounts | list | `[]` | Additional volumeMounts to the event-action-consumer main container |
| event-action-consumer.volumes | list | `[]` | Additional volumes to the event-action-consumer pod |

### SMS Consumer

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| consumer-sms.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| consumer-sms.deploymentAnnotations | object | `{}` | Annotations to be added to the sms consumer Deployment |
| consumer-sms.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to sms consumer |
| consumer-sms.extraEnv | list | `[]` | Environment variables to pass to sms consumer |
| consumer-sms.imageName | string | `"datamanager/consumer-sms"` | sms consumer name string |
| consumer-sms.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the sms consumer |
| consumer-sms.podAnnotations | object | `{}` | Annotations to be added to sms consumer pods |
| consumer-sms.podLabels | object | `{}` | Labels for the deployed pods |
| consumer-sms.replicas | int | `1` | The number of sms consumer pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| consumer-sms.resources | object | `{"limits":{"cpu":"300m","memory":"512Mi"},"requests":{"cpu":"300m","memory":"512Mi"}}` | Resource limits and requests for the sms consumer pods |
| consumer-sms.serviceAccount.annotations | object | `{}` | Annotations applied to created service account |
| consumer-sms.serviceAccount.automountServiceAccountToken | bool | `false` | Automount API credentials for the Service Account |
| consumer-sms.serviceAccount.create | string | `"false"` | Create a ServiceAccount only when set to "true" (string, not boolean) |
| consumer-sms.serviceAccount.labels | object | `{}` | Labels applied to created service account |
| consumer-sms.serviceAccount.name | string | `""` | Service account name |
| consumer-sms.tag | string | `""` | sms consumer image tag |
| consumer-sms.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| consumer-sms.volumeMounts | list | `[]` | Additional volumeMounts to the sms consumer main container |
| consumer-sms.volumes | list | `[]` | Additional volumes to the sms consumer pod |

### Mail Consumer

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| consumer-mail.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| consumer-mail.deploymentAnnotations | object | `{}` | Annotations to be added to the mail consumer Deployment |
| consumer-mail.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to mail consumer |
| consumer-mail.extraEnv | list | `[]` | Environment variables to pass to mail consumer |
| consumer-mail.imageName | string | `"datamanager/consumer-mail"` | mail consumer name string |
| consumer-mail.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the mail consumer |
| consumer-mail.podAnnotations | object | `{}` | Annotations to be added to mail consumer pods |
| consumer-mail.podLabels | object | `{}` | Labels for the deployed pods |
| consumer-mail.replicas | int | `1` | The number of mail consumer pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| consumer-mail.resources | object | `{}` | Resource limits and requests for the mail consumer pods |
| consumer-mail.serviceAccount.annotations | object | `{}` | Annotations applied to created service account |
| consumer-mail.serviceAccount.automountServiceAccountToken | bool | `false` | Automount API credentials for the Service Account |
| consumer-mail.serviceAccount.create | string | `"false"` | Create a ServiceAccount only when set to "true" (string, not boolean) |
| consumer-mail.serviceAccount.labels | object | `{}` | Labels applied to created service account |
| consumer-mail.serviceAccount.name | string | `""` | Service account name |
| consumer-mail.tag | string | `""` | mail consumer image tag |
| consumer-mail.volumeMounts | list | `[]` | Additional volumeMounts to the mail consumer main container |
| consumer-mail.volumes | list | `[]` | Additional volumes to the mail consumer pod |

## legacy

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| legacy.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| legacy.autoScaling | object | `{"enable":"true","maxReplicas":3,"metrics":[{"resource":{"name":"cpu","target":{"averageUtilization":80,"type":"Utilization"}},"type":"Resource"}]}` | https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/ 참조 |
| legacy.deploymentAnnotations | object | `{}` | Annotations to be added to the legacy Deployment |
| legacy.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to legacy |
| legacy.extraEnv | list | `[]` | Environment variables to pass to legacy |
| legacy.imageName | string | `"extension/legacy"` | legacy name string |
| legacy.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the legacy |
| legacy.podAnnotations | object | `{}` | Annotations to be added to legacy pods |
| legacy.podLabels | object | `{}` | Labels for the deployed pods |
| legacy.ports[0].containerPort | int | `80` |  |
| legacy.ports[0].name | string | `"http"` |  |
| legacy.replicas | int | `1` | The number of legacy pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| legacy.resources | object | `{"limits":{"cpu":"1000m","memory":"512Mi"},"requests":{"cpu":"100m","memory":"512Mi"}}` | Resource limits and requests for the legacy pods |
| legacy.serviceAccount.annotations | object | `{}` | Annotations applied to created service account |
| legacy.serviceAccount.automountServiceAccountToken | bool | `false` | Automount API credentials for the Service Account |
| legacy.serviceAccount.create | string | `"false"` | Create a ServiceAccount only when set to "true" (string, not boolean) |
| legacy.serviceAccount.labels | object | `{}` | Labels applied to created service account |
| legacy.serviceAccount.name | string | `""` | Service account name |
| legacy.tag | string | `""` | legacy image tag |
| legacy.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| legacy.volumeMounts | list | `[]` | Additional volumeMounts to the legacy main container |
| legacy.volumes | list | `[]` | Additional volumes to the legacy pod |

## OAuth

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| oauth.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| oauth.autoScaling | object | `{"enable":"true","maxReplicas":4,"metrics":[{"resource":{"name":"cpu","target":{"averageUtilization":80,"type":"Utilization"}},"type":"Resource"}]}` | https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/ 참조 |
| oauth.deploymentAnnotations | object | `{}` | Annotations to be added to the oauth Deployment |
| oauth.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to oauth |
| oauth.extraEnv | list | `[]` | Environment variables to pass to oauth |
| oauth.imageName | string | `"auth/oauth2"` | oauth name string |
| oauth.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the oauth |
| oauth.podAnnotations | object | `{}` | Annotations to be added to oauth pods |
| oauth.podLabels | object | `{}` | Labels for the deployed pods |
| oauth.ports[0].containerPort | int | `80` |  |
| oauth.ports[0].name | string | `"http"` |  |
| oauth.replicas | int | `1` | The number of oauth pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| oauth.resources | object | `{"limits":{"cpu":"1000m","memory":"512Mi"},"requests":{"cpu":"500m","memory":"512Mi"}}` | Resource limits and requests for the oauth pods |
| oauth.serviceAccount.annotations | object | `{}` | Annotations applied to created service account |
| oauth.serviceAccount.automountServiceAccountToken | bool | `false` | Automount API credentials for the Service Account |
| oauth.serviceAccount.create | string | `"false"` | Create a ServiceAccount only when set to "true" (string, not boolean) |
| oauth.serviceAccount.labels | object | `{}` | Labels applied to created service account |
| oauth.serviceAccount.name | string | `""` | Service account name |
| oauth.tag | string | `""` | oauth image tag |
| oauth.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| oauth.volumeMounts | list | `[]` | Additional volumeMounts to the oauth main container |
| oauth.volumes | list | `[]` | Additional volumes to the oauth pod |

## PHI code Auth

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| phi-auth.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| phi-auth.autoScaling | object | `{"enable":"true","maxReplicas":4,"metrics":[{"resource":{"name":"cpu","target":{"averageUtilization":80,"type":"Utilization"}},"type":"Resource"}]}` | https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/ 참조 |
| phi-auth.deploymentAnnotations | object | `{}` | Annotations to be added to the PHI code Auth Deployment |
| phi-auth.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to PHI code |
| phi-auth.extraEnv | list | `[]` | Environment variables to pass to PHI code Auth |
| phi-auth.imageName | string | `"auth/phi-auth"` | PHI code Auth name string |
| phi-auth.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the PHI code Auth |
| phi-auth.podAnnotations | object | `{}` | Annotations to be added to PHI code Auth pods |
| phi-auth.podLabels | object | `{}` | Labels for the deployed pods |
| phi-auth.ports[0].containerPort | int | `80` |  |
| phi-auth.ports[0].name | string | `"http"` |  |
| phi-auth.replicas | int | `1` | The number of PHI code Auth pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| phi-auth.resources | object | `{"limits":{"cpu":"1000m","memory":"512Mi"},"requests":{"cpu":"500m","memory":"512Mi"}}` | Resource limits and requests for the PHI code Auth pods |
| phi-auth.serviceAccount.annotations | object | `{}` | Annotations applied to created service account |
| phi-auth.serviceAccount.automountServiceAccountToken | bool | `false` | Automount API credentials for the Service Account |
| phi-auth.serviceAccount.create | string | `"false"` | Create a ServiceAccount only when set to "true" (string, not boolean) |
| phi-auth.serviceAccount.labels | object | `{}` | Labels applied to created service account |
| phi-auth.serviceAccount.name | string | `""` | Service account name |
| phi-auth.tag | string | `""` | PHI code Auth image tag |
| phi-auth.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| phi-auth.volumeMounts | list | `[]` | Additional volumeMounts to the PHI code Auth main container |
| phi-auth.volumes | list | `[]` | Additional volumes to the PHI code Auth pod |

## Portal

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| portal.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| portal.autoScaling | object | `{"enable":"false"}` | https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/ 참조 |
| portal.deploymentAnnotations | object | `{}` | Annotations to be added to the portal Deployment |
| portal.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to portal |
| portal.extraEnv | list | `[]` | Environment variables to pass to portal |
| portal.imageName | string | `"extension/portal"` | portal name string |
| portal.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the portal |
| portal.podAnnotations | object | `{}` | Annotations to be added to portal pods |
| portal.podLabels | object | `{}` | Labels for the deployed pods |
| portal.ports[0].containerPort | int | `80` |  |
| portal.ports[0].name | string | `"http"` |  |
| portal.replicas | int | `1` | The number of portal pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| portal.resources | object | `{"limits":{"memory":"1Gi"},"requests":{"memory":"1Gi"}}` | Resource limits and requests for the portal pods |
| portal.serviceAccount.annotations | object | `{}` | Annotations applied to created service account |
| portal.serviceAccount.automountServiceAccountToken | bool | `false` | Automount API credentials for the Service Account |
| portal.serviceAccount.create | string | `"false"` | Create a ServiceAccount only when set to "true" (string, not boolean) |
| portal.serviceAccount.labels | object | `{}` | Labels applied to created service account |
| portal.serviceAccount.name | string | `""` | Service account name |
| portal.tag | string | `""` | portal image tag |
| portal.tolerations | list | `[]` (defaults to tolerations) | [Tolerations] for use with node taints |
| portal.volumeMounts | list | `[]` | Additional volumeMounts to the portal main container |
| portal.volumes | list | `[]` | Additional volumes to the portal pod |

## Scheduler

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| scheduler.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| scheduler.deploymentAnnotations | object | `{}` | Annotations to be added to the scheduler Deployment |
| scheduler.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to scheduler |
| scheduler.extraEnv | list | `[]` | Environment variables to pass to scheduler |
| scheduler.imageName | string | `"extension/scheduler"` | scheduler name string |
| scheduler.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the scheduler |
| scheduler.podAnnotations | object | `{}` | Annotations to be added to scheduler pods |
| scheduler.podLabels | object | `{}` | Labels for the deployed pods |
| scheduler.ports[0].containerPort | int | `80` |  |
| scheduler.ports[0].name | string | `"http"` |  |
| scheduler.replicas | int | `1` | The number of scheduler pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| scheduler.resources | object | `{"limits":{"memory":"512Mi"},"requests":{"memory":"256Mi"}}` | Resource limits and requests for the scheduler pods |
| scheduler.serviceAccount.annotations | object | `{}` | Annotations applied to created service account |
| scheduler.serviceAccount.automountServiceAccountToken | bool | `false` | Automount API credentials for the Service Account |
| scheduler.serviceAccount.create | string | `"false"` | Create a ServiceAccount only when set to "true" (string, not boolean) |
| scheduler.serviceAccount.labels | object | `{}` | Labels applied to created service account |
| scheduler.serviceAccount.name | string | `""` | Service account name |
| scheduler.tag | string | `""` | scheduler image tag |
| scheduler.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| scheduler.volumeMounts | list | `[]` | Additional volumeMounts to the scheduler main container |
| scheduler.volumes | list | `[]` | Additional volumes to the scheduler pod |

## Provider Manager

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| provider-manager.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| provider-manager.autoScaling | object | `{"enable":"true","maxReplicas":3,"metrics":[{"resource":{"name":"cpu","target":{"averageUtilization":80,"type":"Utilization"}},"type":"Resource"}]}` | https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/ 참조 |
| provider-manager.deploymentAnnotations | object | `{}` | Annotations to be added to the provider-manager Deployment |
| provider-manager.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to provider-manager |
| provider-manager.extraEnv | list | `[]` | Environment variables to pass to provider-manager |
| provider-manager.imageName | string | `"extension/provider-manager"` | provider-manager name string |
| provider-manager.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the provider-manager |
| provider-manager.podAnnotations | object | `{}` | Annotations to be added to provider-manager pods |
| provider-manager.podLabels | object | `{}` | Labels for the deployed pods |
| provider-manager.ports[0].containerPort | int | `80` |  |
| provider-manager.ports[0].name | string | `"http"` |  |
| provider-manager.replicas | int | `1` | The number of provider-manager pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| provider-manager.resources | object | `{"limits":{"cpu":"1000m","memory":"512Mi"},"requests":{"cpu":"100m","memory":"256Mi"}}` | Resource limits and requests for the provider-manager pods |
| provider-manager.serviceAccount.annotations | object | `{}` | Annotations applied to created service account |
| provider-manager.serviceAccount.automountServiceAccountToken | bool | `false` | Automount API credentials for the Service Account |
| provider-manager.serviceAccount.create | string | `"false"` | Create a ServiceAccount only when set to "true" (string, not boolean) |
| provider-manager.serviceAccount.labels | object | `{}` | Labels applied to created service account |
| provider-manager.serviceAccount.name | string | `""` | Service account name |
| provider-manager.tag | string | `""` | provider-manager image tag |
| provider-manager.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| provider-manager.volumeMounts | list | `[]` | Additional volumeMounts to the provider-manager main container |
| provider-manager.volumes | list | `[]` | Additional volumes to the provider-manager pod |

## FHIR Module

### HAPI Fhir

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| hapi-fhir.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| hapi-fhir.autoScaling | object | `{"enable":"false"}` | https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/ 참조 |
| hapi-fhir.deploymentAnnotations | object | `{}` | Annotations to be added to the hapi-fhir Deployment |
| hapi-fhir.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to hapi-fhir |
| hapi-fhir.extraEnv | list | `[]` | Environment variables to pass to hapi-fhir |
| hapi-fhir.imageName | string | `"fhir/server"` | hapi-fhir name string |
| hapi-fhir.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the hapi-fhir |
| hapi-fhir.podAnnotations | object | `{}` | Annotations to be added to hapi-fhir pods |
| hapi-fhir.podLabels | object | `{}` | Labels for the deployed pods |
| hapi-fhir.ports[0].containerPort | int | `8082` |  |
| hapi-fhir.ports[0].name | string | `"http"` |  |
| hapi-fhir.ports[0].port | int | `80` |  |
| hapi-fhir.replicas | int | `1` | The number of hapi-fhir pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| hapi-fhir.resources | object | `{"limits":{"memory":"2Gi"},"requests":{"memory":"2Gi"}}` | Resource limits and requests for the hapi-fhir pods |
| hapi-fhir.serviceAccount.annotations | object | `{}` | Annotations applied to created service account |
| hapi-fhir.serviceAccount.automountServiceAccountToken | bool | `false` | Automount API credentials for the Service Account |
| hapi-fhir.serviceAccount.create | string | `"false"` | Create a ServiceAccount only when set to "true" (string, not boolean) |
| hapi-fhir.serviceAccount.labels | object | `{}` | Labels applied to created service account |
| hapi-fhir.serviceAccount.name | string | `""` | Service account name |
| hapi-fhir.tag | string | `"6.4.0"` | hapi-fhir image tag |
| hapi-fhir.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| hapi-fhir.volumeMounts | list | `[{"mountPath":"/opt/phi/conf","name":"repo-conf-volume"}]` | Additional volumeMounts to the hapi-fhir main container |
| hapi-fhir.volumes | list | `[{"name":"repo-conf-volume","secret":{"secretName":"repo-config"}}]` | Additional volumes to the hapi-fhir pod |

### FHIR batch

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| fhir-batch.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| fhir-batch.deploymentAnnotations | object | `{}` | Annotations to be added to the fhir batch Deployment |
| fhir-batch.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to fhir batch |
| fhir-batch.extraEnv | list | `[]` | Environment variables to pass to fhir batch |
| fhir-batch.imageName | string | `"fhir/batch"` | fhir batch image name string |
| fhir-batch.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the fhir batch |
| fhir-batch.podAnnotations | object | `{}` | Annotations to be added to fhir batch pods |
| fhir-batch.podLabels | object | `{}` | Labels for the deployed pods |
| fhir-batch.replicas | int | `1` | The number of fhir batch pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| fhir-batch.resources | object | `{"limits":{"memory":"2Gi"},"requests":{"memory":"1Gi"}}` | Resource limits and requests for the fhir-batch pods |
| fhir-batch.serviceAccount.annotations | object | `{}` | Annotations applied to created service account |
| fhir-batch.serviceAccount.automountServiceAccountToken | bool | `false` | Automount API credentials for the Service Account |
| fhir-batch.serviceAccount.create | string | `"false"` | Create a ServiceAccount only when set to "true" (string, not boolean) |
| fhir-batch.serviceAccount.labels | object | `{}` | Labels applied to created service account |
| fhir-batch.serviceAccount.name | string | `""` | Service account name |
| fhir-batch.tag | string | `""` | fhir batch image tag |
| fhir-batch.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| fhir-batch.volumeMounts | list | `[]` | Additional volumeMounts to the fhir batch main container |
| fhir-batch.volumes | list | `[]` | Additional volumes to the fhir batch pod |

### FHIR gateway

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| fhir-gateway.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| fhir-gateway.autoScaling | object | `{"enable":"false"}` | https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/ 참조 |
| fhir-gateway.deploymentAnnotations | object | `{}` | Annotations to be added to the fhir gateway Deployment |
| fhir-gateway.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to fhir gateway |
| fhir-gateway.extraEnv | list | `[]` | Environment variables to pass to fhir gateway |
| fhir-gateway.imageName | string | `"fhir/gateway"` | fhir gateway name string |
| fhir-gateway.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the fhir gateway |
| fhir-gateway.podAnnotations | object | `{}` | Annotations to be added to fhir gateway pods |
| fhir-gateway.podLabels | object | `{}` | Labels for the deployed pods |
| fhir-gateway.ports[0].containerPort | int | `80` |  |
| fhir-gateway.ports[0].name | string | `"http"` |  |
| fhir-gateway.replicas | int | `1` | The number of fhir gateway pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| fhir-gateway.resources | object | `{"limits":{"memory":"3Gi"},"requests":{"memory":"1Gi"}}` | Resource limits and requests for the fhir-gateway pods |
| fhir-gateway.serviceAccount.annotations | object | `{}` | Annotations applied to created service account |
| fhir-gateway.serviceAccount.automountServiceAccountToken | bool | `false` | Automount API credentials for the Service Account |
| fhir-gateway.serviceAccount.create | string | `"false"` | Create a ServiceAccount only when set to "true" (string, not boolean) |
| fhir-gateway.serviceAccount.labels | object | `{}` | Labels applied to created service account |
| fhir-gateway.serviceAccount.name | string | `""` | Service account name |
| fhir-gateway.tag | string | `""` | fhir gateway image tag |
| fhir-gateway.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| fhir-gateway.volumeMounts | list | `[]` | Additional volumeMounts to the fhir gateway main container |
| fhir-gateway.volumes | list | `[]` | Additional volumes to the fhir gateway pod |

## Notify Module

### Notify Manager

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| notify-manager.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| notify-manager.deploymentAnnotations | object | `{}` | Annotations to be added to the notify-manager Deployment |
| notify-manager.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to notify-manager |
| notify-manager.extraEnv | list | `[]` | Environment variables to pass to notify-manager |
| notify-manager.imageName | string | `"notify/notify-manager"` | notify-manager name string |
| notify-manager.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the notify-manager |
| notify-manager.podAnnotations | object | `{}` | Annotations to be added to notify-manager pods |
| notify-manager.podLabels | object | `{}` | Labels for the deployed pods |
| notify-manager.ports[0].containerPort | int | `80` |  |
| notify-manager.ports[0].name | string | `"http"` |  |
| notify-manager.replicas | int | `1` | The number of notify-manager pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| notify-manager.resources | object | `{"limits":{"memory":"512Mi"},"requests":{"memory":"512Mi"}}` | Resource limits and requests for the notify-manager pods |
| notify-manager.serviceAccount.annotations | object | `{}` | Annotations applied to created service account |
| notify-manager.serviceAccount.automountServiceAccountToken | bool | `false` | Automount API credentials for the Service Account |
| notify-manager.serviceAccount.create | string | `"false"` | Create a ServiceAccount only when set to "true" (string, not boolean) |
| notify-manager.serviceAccount.labels | object | `{}` | Labels applied to created service account |
| notify-manager.serviceAccount.name | string | `""` | Service account name |
| notify-manager.tag | string | `""` | notify-manager image tag |
| notify-manager.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| notify-manager.volumeMounts | list | `[]` | Additional volumeMounts to the notify-manager main container |
| notify-manager.volumes | list | `[]` | Additional volumes to the notify-manager pod |

### Notify Transfer

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| notify-transfer.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| notify-transfer.deploymentAnnotations | object | `{}` | Annotations to be added to the notify-transfer Deployment |
| notify-transfer.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to notify-transfer |
| notify-transfer.extraEnv | list | `[]` | Environment variables to pass to notify-transfer |
| notify-transfer.imageName | string | `"notify/notify-transfer"` | notify-transfer name string |
| notify-transfer.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the notify-transfer |
| notify-transfer.podAnnotations | object | `{}` | Annotations to be added to notify-transfer pods |
| notify-transfer.podLabels | object | `{}` | Labels for the deployed pods |
| notify-transfer.replicas | int | `1` | The number of notify-transfer pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| notify-transfer.resources | object | `{"limits":{"memory":"512Mi"},"requests":{"memory":"512Mi"}}` | Resource limits and requests for the notify-transfer pods |
| notify-transfer.serviceAccount.annotations | object | `{}` | Annotations applied to created service account |
| notify-transfer.serviceAccount.automountServiceAccountToken | bool | `false` | Automount API credentials for the Service Account |
| notify-transfer.serviceAccount.create | string | `"false"` | Create a ServiceAccount only when set to "true" (string, not boolean) |
| notify-transfer.serviceAccount.labels | object | `{}` | Labels applied to created service account |
| notify-transfer.serviceAccount.name | string | `""` | Service account name |
| notify-transfer.tag | string | `""` | notify-transfer image tag |
| notify-transfer.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| notify-transfer.volumeMounts | list | `[]` | Additional volumeMounts to the notify-transfer main container |
| notify-transfer.volumes | list | `[]` | Additional volumes to the notify-transfer pod |

## Consent Manager

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| consent-manager.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| consent-manager.autoScaling | object | `{"enable":"true","maxReplicas":3,"metrics":[{"resource":{"name":"cpu","target":{"averageUtilization":80,"type":"Utilization"}},"type":"Resource"}]}` | https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/ 참조 |
| consent-manager.deploymentAnnotations | object | `{}` | Annotations to be added to the consent-manager Deployment |
| consent-manager.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to consent-manager |
| consent-manager.extraEnv | list | `[]` | Environment variables to pass to consent-manage |
| consent-manager.imageName | string | `"extension/consent-manager"` | consent-manager imageName string |
| consent-manager.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the consent-manage |
| consent-manager.podAnnotations | object | `{}` | Annotations to be added to consent-manager pods |
| consent-manager.podLabels | object | `{}` | Labels for the deployed pods |
| consent-manager.ports[0].containerPort | int | `80` |  |
| consent-manager.ports[0].name | string | `"http"` |  |
| consent-manager.replicas | int | `1` | The number of fhir gateway pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| consent-manager.resources | object | `{"limits":{"cpu":"1500m","memory":"512Mi"},"requests":{"cpu":"500m","memory":"512Mi"}}` | Resource limits and requests for the consent-manager pods |
| consent-manager.serviceAccount.annotations | object | `{}` | Annotations applied to created service account |
| consent-manager.serviceAccount.automountServiceAccountToken | bool | `false` | Automount API credentials for the Service Account |
| consent-manager.serviceAccount.create | string | `"false"` | Create a ServiceAccount only when set to "true" (string, not boolean) |
| consent-manager.serviceAccount.labels | object | `{}` | Labels applied to created service account |
| consent-manager.serviceAccount.name | string | `""` | Service account name |
| consent-manager.tag | string | `""` | consent-manage image tag |
| consent-manager.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| consent-manager.volumeMounts | list | `[]` | Additional volumeMounts to the consent-manager main container |
| consent-manager.volumes | list | `[]` | Additional volumes to the consent-manager pod |

## External Module Log Listener

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| external-log-listener.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| external-log-listener.autoScaling | object | `{"enable":"true","maxReplicas":2,"metrics":[{"resource":{"name":"cpu","target":{"averageUtilization":80,"type":"Utilization"}},"type":"Resource"}]}` | https://kubernetes.io/ko/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/ 참조 |
| external-log-listener.deploymentAnnotations | object | `{}` | Annotations to be added to the log-listener Deployment |
| external-log-listener.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to log-listener |
| external-log-listener.extraEnv | list | `[]` | Environment variables to pass to log-listener |
| external-log-listener.imageName | string | `"extension/external-log-listener"` | log-listener imageName string |
| external-log-listener.imagePullPolicy | string | `""` (defaults to image.imagePullPolicy) | Image pull policy for the log-listener |
| external-log-listener.podAnnotations | object | `{}` | Annotations to be added to log-listener pods |
| external-log-listener.podLabels | object | `{}` | Labels for the deployed pods |
| external-log-listener.ports[0].containerPort | int | `80` |  |
| external-log-listener.ports[0].name | string | `"http"` |  |
| external-log-listener.replicas | int | `1` | The number of log-listener pods to run. Additional replicas will cause sharding of managed clusters across number of replicas. |
| external-log-listener.resources | object | `{"limits":{"cpu":"1000m","memory":"512Mi"},"requests":{"cpu":"500m","memory":"512Mi"}}` | Resource limits and requests for the log-listener pods |
| external-log-listener.serviceAccount.annotations | object | `{}` | Annotations applied to created service account |
| external-log-listener.serviceAccount.automountServiceAccountToken | bool | `false` | Automount API credentials for the Service Account |
| external-log-listener.serviceAccount.create | string | `"false"` | Create a ServiceAccount only when set to "true" (string, not boolean) |
| external-log-listener.serviceAccount.labels | object | `{}` | Labels applied to created service account |
| external-log-listener.serviceAccount.name | string | `""` | Service account name |
| external-log-listener.tag | string | `""` | log-listener image tag |
| external-log-listener.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| external-log-listener.volumeMounts | list | `[]` | Additional volumeMounts to the log-listener main container |
| external-log-listener.volumes | list | `[]` | Additional volumes to the log-listener pod |

## Data Processor

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| data-processor.affinity | object | `{ }` (defaults to affinity preset) | Assign custom [affinity] rules to the deployment |
| data-processor.deploymentAnnotations | object | `{}` |  |
| data-processor.envFrom | list | `[ ]` (See [values.yaml]) | envFrom to pass to data-processor |
| data-processor.extraEnv | list | `[]` |  |
| data-processor.imageName | string | `"extension/data-processor"` | data-processor imageName string |
| data-processor.podAnnotations | object | `{}` |  |
| data-processor.podLabels | object | `{}` |  |
| data-processor.ports[0].containerPort | int | `80` |  |
| data-processor.ports[0].name | string | `"http"` |  |
| data-processor.replicas | int | `1` |  |
| data-processor.resources.limits.cpu | string | `"1000m"` |  |
| data-processor.resources.limits.memory | string | `"512Mi"` |  |
| data-processor.resources.requests.cpu | string | `"200m"` |  |
| data-processor.resources.requests.memory | string | `"256Mi"` |  |
| data-processor.serviceAccount.annotations | object | `{}` | Annotations applied to created service account |
| data-processor.serviceAccount.automountServiceAccountToken | bool | `false` | Automount API credentials for the Service Account |
| data-processor.serviceAccount.create | string | `"false"` | Create a ServiceAccount only when set to "true" (string, not boolean) |
| data-processor.serviceAccount.labels | object | `{}` | Labels applied to created service account |
| data-processor.serviceAccount.name | string | `""` | Service account name |
| data-processor.tolerations | list | `[ ]` (defaults to tolerations) | [Tolerations] for use with node taints |
| data-processor.volumeMounts | list | `[]` |  |
| data-processor.volumes | list | `[]` |  |
